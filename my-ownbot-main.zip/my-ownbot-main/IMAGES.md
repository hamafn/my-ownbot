Here are some bot images:

![image](https://user-images.githubusercontent.com/74746579/159154628-fb2c9ab4-18aa-4083-916e-0c854d5c8cfd.png)


![image](https://user-images.githubusercontent.com/74746579/159154633-021efcf3-979a-4991-b95c-42cb1a4e8a5b.png)


![image](https://user-images.githubusercontent.com/74746579/159154636-edde6b68-4feb-4e10-bcd5-84bd43e5d2bd.png)


![image](https://user-images.githubusercontent.com/74746579/159154640-a82a1c85-9e6f-4d7f-9e8a-bd4a4543ab68.png)


![image](https://user-images.githubusercontent.com/74746579/159154649-339d6bec-7b32-4a0e-91f6-e171aed79214.png)


![image](https://user-images.githubusercontent.com/74746579/159154654-371fe15f-dd1b-4a51-8e29-45dae14c2e15.png)


![image](https://media.discordapp.net/attachments/935050594572447793/955023988587913266/ipplooo.gif)
