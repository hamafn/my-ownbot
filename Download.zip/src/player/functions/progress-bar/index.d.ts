declare function progressBar(total: number, current: number, size?:number, empty?: string, line?: string, slider?: string, slider2?: string): Array<string>
export { progressBar }
